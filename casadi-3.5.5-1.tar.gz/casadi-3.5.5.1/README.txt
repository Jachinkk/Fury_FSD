The directory structure is as follows:

casadi - the c++ source code
cmake - cmake scripts, e.g. FindBlah.cmake
docs - documentation and examples
experimental - mostly deprecated extensions that don't belong in casadi/
external_packages - source for 3rd party packages which casadi builds and interfaces
misc - mostly handy scripts
swig - for buildinge python (and other) interfaces
test - unit tests
