# Symbolic code


blablah because `Foo` is bar.

```python
x = MX.sym('x',3)
```



We need ``$\sqrt{x}$``.


```math
\frac{\sqrt{x+y}}{2}
```

## subheading
